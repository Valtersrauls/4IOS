//
//  DocViewCell.swift
//  4MD
//
//  Created by User on 17.04.19.
//  Copyright © 2019. g. Apple Inc. All rights reserved.
//

import UIKit

class DocViewCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var size: UILabel!
    @IBOutlet weak var button: UIButton!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
