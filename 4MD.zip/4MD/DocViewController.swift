//
//  DocViewController.swift
//  4MD
//
//  Created by User on 17.04.19.
//  Copyright © 2019. g. Apple Inc. All rights reserved.
//

import UIKit

class DocViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    var documents = [JsonDec]()
    var fileName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchDocs()
    }
    
    func fetchDocs() -> Void{
        let url = URL(string: "https://api.github.com/repos/Valtersrauls/RestAPI/contents/Documents")
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "GET"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            guard let data = data, error == nil, response != nil else { print("error")
                return
                
            }
            print("Downloading finished")
            print(data)
            do
            {
                let decoder = JSONDecoder()
                let downloadedDocs = try decoder.decode([JsonDec].self, from: data)
                self.documents = downloadedDocs
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
                
            } catch {
                print("error after downloading")
            }
        }
        task.resume()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return documents.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "DocViewCell") as? DocViewCell else {
            return UITableViewCell()
        }
        cell.name.text = documents[indexPath.row].name
        let sizeMB = documents[indexPath.row].size / 1024
        cell.size.text = String(sizeMB) + " KB"
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var localPathUrl = download(fileName: documents[indexPath.row].name, fileUrlString: documents[indexPath.row].download_url)
       // localPathUrl = "file:///Users/user/Library/Developer/CoreSimulator/Devices/B897F092-8D1C-467F-9C8F-10969D95984E/data/Containers/Data/Application/95B49B7C-6374-466B-8508-847D540C2167/Documents/Datu_bazes_2017.pdf"
        
        localPath = localPathUrl.absoluteString
//        localPath = "file:///Users/user/Library/Developer/CoreSimulator/Devices/B897F092-8D1C-467F-9C8F-10969D95984E/data/Containers/Data/Application/3AB66A03-72CC-4E61-9281-2A93FE81240E/Documents/Datu_bazes_2017.pdf"
        fileName = documents[indexPath.row].name
        performSegue(withIdentifier: "showDoc", sender: self)
    }
    
    var localPath:String? = nil
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let VC = segue.destination as! OpenDocViewController
        VC.title = fileName
        VC.filePath = localPath
    }
}
