//
//  OpenDocViewController.swift
//  4MD
//
//  Created by User on 17.04.19.
//  Copyright © 2019. g. Apple Inc. All rights reserved.
//

import UIKit
import WebKit

class OpenDocViewController: UIViewController, WKUIDelegate, WKNavigationDelegate {
    @IBOutlet weak var webView: WKWebView!
    //@IBOutlet weak var activity: UIActivityIndicatorView!
    
    var filePath: String? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        //activity.isHidden = true
        webView.navigationDelegate = self
        if let fileName = title {
            openFile(filePath ?? "Error: No file path set")
            print("File ", fileName, " opened")
        } else {
            print("Nothing to open")
        }
    }
    
    private func openFile(_ fileName: String) {
        let url: URL = URL(fileURLWithPath: fileName)
        webView.loadFileURL(url, allowingReadAccessTo: url)
    }
}
