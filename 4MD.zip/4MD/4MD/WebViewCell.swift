//
//  WebViewCell.swift
//  4MD
//
//  Created by User on 29/04/2019.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class WebViewCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var size: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
