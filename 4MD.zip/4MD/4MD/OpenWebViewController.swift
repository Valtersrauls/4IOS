//
//  OpenWebViewController.swift
//  4MD
//
//  Created by User on 29/04/2019.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit
import WebKit

class OpenWebViewController: UIViewController, WKUIDelegate, WKNavigationDelegate {
    @IBOutlet weak var webView: WKWebView!
    
    var filePath: String? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        //activity.isHidden = true
        webView.navigationDelegate = self
        if let fileName = title {
            openFile(filePath ?? "Error: No file path set")
            print("File ", fileName, " opened")
        } else {
            print("Nothing to open")
        }
    }
    
    private func openFile(_ fileName: String) {
        let url: URL = URL(fileURLWithPath: fileName)
        webView.loadFileURL(url, allowingReadAccessTo: url)
    }
}
