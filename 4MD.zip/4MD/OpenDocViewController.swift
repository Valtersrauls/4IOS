//
//  OpenDocViewController.swift
//  4MD
//
//  Created by User on 17.04.19.
//  Copyright © 2019. g. Apple Inc. All rights reserved.
//

import UIKit
import WebKit

class OpenDocViewController: UIViewController {
    @IBOutlet weak var webView: WKWebView!
    
    var filePath: String? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.navigationDelegate = self as? WKNavigationDelegate
        if let fileName = title {
            openFile(filePath ?? "Error: No file path set")
            print("File ", fileName, " opened")
        } else {
            print("Nothing to open")
        }
    }
    
    private func openFile(_ fileName: String) {
       // if let filePath = Bundle.main.url(forResource: fileName, withExtension: "pdf"){
        let url: URL = URL(fileURLWithPath: fileName)
        webView.loadFileURL(url, allowingReadAccessTo: url)
           // let request = URLRequest(url: url)
            //print("Request: ", request)
            //webView.loadFi(request)
//        } else {
//            print("Error: file value nil")
//        }
    }

}
